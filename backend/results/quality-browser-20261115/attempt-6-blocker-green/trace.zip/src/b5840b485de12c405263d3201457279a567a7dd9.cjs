/* Real mounted API/browser acceptance. No request fulfillment or runtime fixtures. */
const fs = require('fs'), path = require('path'), assert = require('assert/strict'), crypto = require('crypto');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/Users/tejas/.npm/_npx/e41f203b7505f1fb/node_modules/playwright');
const output = process.argv[2], manifest = JSON.parse(fs.readFileSync(process.argv[3]));
assert(!fs.existsSync(output), 'Choose a fresh output directory; preserve earlier attempts.');
fs.mkdirSync(output, {recursive:true});
const base = 'http://127.0.0.1:5198', api = manifest.api;
const resuming = process.argv.includes('--resume');
(async()=>{
 const browser=await chromium.launch(), context=await browser.newContext({viewport:{width:1440,height:1000},serviceWorkers:'block'}), page=await context.newPage();
 await context.tracing.start({screenshots:true,snapshots:true,sources:true});
 page.setDefaultTimeout(15000);
 const evidence={mode:resuming?'resume_persisted_case':'new_case',requests:[],checks:[],errors:[],external_requests:[]};
 page.on('pageerror',e=>evidence.errors.push(String(e)));
 page.on('response',r=>{if(r.url().startsWith(api)) evidence.requests.push({path:new URL(r.url()).pathname,status:r.status(),method:r.request().method()});});
 page.on('request',r=>{if(/^https?:/.test(r.url())&&!r.url().startsWith(api)&&!r.url().startsWith(base))evidence.external_requests.push(r.url());});
 const check=(name,value)=>{assert(value,name);evidence.checks.push(name);};
 async function login(email,next){await page.goto(`${base}/sign-in/?next=${encodeURIComponent(next)}`);await page.getByLabel('Work email').fill(email);await page.getByLabel('Password',{exact:true}).fill('sievance-local');await page.getByRole('button',{name:'Sign in',exact:true}).click();}
 const button=name=>page.getByRole('button',{name,exact:true});
 try{
 await login('msat@sievance.local',`/signals/?id=${manifest.signal_id}`);
 await page.getByRole('heading',{name:'Synthetic oxygen excursion',exact:true}).waitFor({timeout:60000});
 await page.getByTestId('signal-observation-point').first().waitFor();
 const signalResponse=await context.request.get(`${api}/v1/signals/${manifest.signal_id}`,{headers:{'X-Tenant-Id':'demo-northfield','X-Actor-Id':'dev-msat'}});const persistedSignal=await signalResponse.json();evidence.source_observations=persistedSignal.observations;
 const actualPoints=persistedSignal.observations.filter(p=>typeof(p.original_value??p.value)==='number'&&p.event_time);
 check('all real historian points without a delivery, retaining source revisions',actualPoints.length>=3&&await page.getByTestId('signal-observation-point').count()===actualPoints.length);
 const pointLabels=await page.getByTestId('signal-observation-point').evaluateAll(nodes=>nodes.map(n=>n.getAttribute('aria-label')));
 check('source times values units and revisions match persisted observations',actualPoints.every(p=>pointLabels.some(label=>label.includes(`${p.event_time}: ${p.original_value??p.value} ${p.original_unit??p.unit}`)&&label.includes(`revision ${p.evidence_ref.revision}`))));
 await page.getByTestId('signal-observation-point').last().click();
 await page.getByRole('link',{name:'Prepare Quality workspace',exact:true}).click();
 if(!resuming){
 check('batch and equipment context carried into initiation',await page.getByLabel('Batch identifier',{exact:true}).inputValue()==='SYN-001'&&await page.getByLabel('Equipment identifier',{exact:true}).inputValue()==='SYN-V1');
 await page.getByLabel('Investigation owner',{exact:true}).selectOption('dev-msat');
 await page.getByLabel('QA reviewer',{exact:true}).selectOption('dev-qa');
 await button('Create workspace').click();
 }else check('resume explicitly requires existing signal case',Boolean(persistedSignal.case_id));
 await page.getByTestId('quality-workspace').waitFor();
 await page.waitForURL(/\/quality\/\?case=/);
 const caseId=new URL(page.url()).searchParams.get('case');check('same case link',Boolean(caseId));evidence.case_id=caseId;
 if(resuming)check('resume preserves original case identity',caseId===persistedSignal.case_id);
 if(process.argv.includes('--inspect-blockers')){check('blocker names evidence and responsible owner',/Evidence needed: Calibration certificate · owner dev-msat/.test(await page.getByTestId('quality-gaps').innerText()));await page.screenshot({path:path.join(output,'blocker-readable.png'),fullPage:true});check('no browser exceptions',evidence.errors.length===0);check('no external browser requests',evidence.external_requests.length===0);evidence.status='passed';return;}
 await page.screenshot({path:path.join(output,'workspace-compact.png'),fullPage:true});
 await page.goto(`${base}/signals/?id=${manifest.signal_id}`);const sameCase=page.getByRole('link',{name:'Continue this case in Quality',exact:true});await sameCase.waitFor();check('signal reopens same case',new URL(await sameCase.getAttribute('href'),base).searchParams.get('case')===caseId);await sameCase.click();await page.getByTestId('quality-workspace').waitFor();
 if(!resuming){await page.getByLabel('Decision reason').fill('Prepare local deviation based on observed excursion');await button('Assign investigation').click();await button('Prepare evidence').click();}
 await page.getByText('Sources and timeline',{exact:true}).click();await page.getByTestId('source-row').first().waitFor();await page.getByRole('button',{name:/Inspect evidence/}).first().click();
 await page.getByTestId('source-original').getByText(/Synthetic acceptance inputs/).waitFor();
 check('pinned actual original', (await page.getByTestId('source-original').innerText()).includes('scientific_models'));
 const downloadPromise=page.waitForEvent('download');await page.getByRole('button',{name:/Download original revision/}).click();const originalDownload=await downloadPromise;await originalDownload.saveAs(path.join(output,'original-pinned-source'));
 check('download exact original bytes',crypto.createHash('sha256').update(fs.readFileSync(path.join(output,'original-pinned-source'))).digest('hex')===manifest.source_sha256);
 check('untrusted source script escaped',await page.evaluate(()=>window.__sourceExecuted===undefined));
 await button('Close source').click();
 await page.getByText('Assessment and impact',{exact:true}).click();
 if(!resuming){
 await page.getByLabel('Event description',{exact:true}).fill('Oxygen fell to 2 mg/L in synthetic batch SYN-001.');
 await page.getByLabel('Investigation scope',{exact:true}).fill('SYN-001, vessel SYN-V1, 10:00–12:00 source time.');
 await page.getByLabel('Technical summary',{exact:true}).fill('Observed decline; cause remains unresolved.');
 await page.getByLabel('Limitations',{exact:true}).fill('Synthetic data; calibration not supplied.');
 await page.getByLabel('Impact assessment',{exact:true}).fill('SYN-001 reviewed; distribution unknown, external QA disposition pending.');
 await button('Save assessment').click();
 }else check('resume retains saved event description',await page.getByLabel('Event description',{exact:true}).inputValue()==='Oxygen fell to 2 mg/L in synthetic batch SYN-001.');
 await page.getByText('Scientific work and hypotheses',{exact:true}).click();if(!resuming)await button('Run supplied scientific configurations').click();
 await page.getByTestId('science-run').first().waitFor();check('real source-complete science completed', /completed/.test(await page.getByTestId('science-run').first().innerText()));
 await page.getByRole('cell',{name:'100',exact:true}).first().waitFor();
 if(!resuming){await page.getByLabel('Hypothesis or follow-up').fill('Transfer limitation remains unconfirmed.');await button('Record hypothesis').click();}await page.getByText('Transfer limitation remains unconfirmed. · hypothesis',{exact:true}).waitFor();
 await page.getByText('Actions and evidence requests',{exact:true}).click();
 if(!resuming){await page.getByLabel('Evidence needed').fill('Calibration certificate');await button('Request evidence').click();}
 await page.getByText('Calibration certificate',{exact:true}).waitFor();
 if(!resuming){await page.getByLabel('Action description').fill('Review vessel calibration before disposition');await page.getByLabel('Action deadline').fill('2026-12-01');await button('Add action').click();}else await page.getByText('Review vessel calibration before disposition',{exact:true}).waitFor();
 await page.reload();await page.getByTestId('quality-workspace').waitFor();
 await page.getByText('Assessment and impact',{exact:true}).click();check('scope survives reload',await page.getByLabel('Investigation scope',{exact:true}).inputValue()==='SYN-001, vessel SYN-V1, 10:00–12:00 source time.');
 await page.getByLabel('Decision reason').fill('Ready for inspection with open evidence request');await button('Submit technical review').click();
 await page.getByLabel('Decision reason').fill('Technical review completed for QA inspection');await button('Submit QA review').click();
 await page.screenshot({path:path.join(output,'owner-review.png'),fullPage:true});
 await context.clearCookies();await page.evaluate(()=>localStorage.clear());
 await login('qa@sievance.local',`/quality/?case=${caseId}`);await page.getByTestId('quality-workspace').waitFor();
 await page.getByLabel('Decision reason').fill('Review incomplete material evidence');
 check('QA approval blocked by unresolved evidence with reason supplied',await button('Approve local preparation').isDisabled());
 await page.getByLabel('Decision reason').fill('Obtain calibration certificate before local approval');await button('Return for more evidence').click();await page.getByTestId('workflow-state').getByText('returned',{exact:true}).waitFor();
 await page.getByText('Reviews and activity',{exact:true}).click();await page.getByText('Obtain calibration certificate before local approval',{exact:false}).first().waitFor();
 const exportResponsePromise=page.waitForResponse(r=>r.url().endsWith(`/v1/quality/workspaces/${caseId}/export`));const packageDownloadPromise=page.waitForEvent('download');
 await button('Export local package').click();await page.getByTestId('export-label').waitFor();const exportedPackage=await(await exportResponsePromise).json();const packageDownload=await packageDownloadPromise;await packageDownload.saveAs(path.join(output,'local-pending-package.json'));
 check('local pending handoff label',/pending_external_approval/.test(await page.getByTestId('export-label').innerText()));
 check('scope and description retained in export',exportedPackage.workspace.assessment.scope==='SYN-001, vessel SYN-V1, 10:00–12:00 source time.'&&exportedPackage.workspace.assessment.event_description==='Oxygen fell to 2 mg/L in synthetic batch SYN-001.');
 check('export retains review history and no external receipt',exportedPackage.workspace.reviews.length>=2&&exportedPackage.external_receipt===null);
 const headers={'X-Tenant-Id':'demo-northfield','X-Actor-Id':'dev-msat'};
 let r=await context.request.get(`${api}/v1/quality/workspaces/${caseId}`,{headers});let w=await r.json();
 check('persisted request/action/review',w.requests.length===1 && w.actions.length===1 && w.reviews.length>=2);
 check('source revision preserved',w.sources.some(s=>s.ref.id===manifest.source_ref.id&&s.ref.revision===manifest.source_ref.revision));
 check('hypothesis retained separately from science',w.hypotheses.some(h=>h.text==='Transfer limitation remains unconfirmed.'));
 check('owner lacks QA approval action',!w.allowed_actions.includes('approve_local'));
 r=await context.request.post(`${api}/v1/quality/workspaces/${caseId}/transition`,{headers:{...headers,'Idempotency-Key':'unauthorized-browser-proof'},data:{expected_revision:w.revision,transition:'approve_local',reason:'Forbidden'}});check('real backend denies owner QA approval',r.status()===403);
 check('no browser exceptions',evidence.errors.length===0);
 check('no external browser requests',evidence.external_requests.length===0);
 await page.screenshot({path:path.join(output,'qa-return.png'),fullPage:true});evidence.status='passed';
 }catch(e){evidence.status='failed';evidence.error=String(e);evidence.body=await page.locator('body').innerText();await page.screenshot({path:path.join(output,'failure.png'),fullPage:true});process.exitCode=1;}
 finally{await context.tracing.stop({path:path.join(output,'trace.zip')});fs.writeFileSync(path.join(output,'result.json'),JSON.stringify(evidence,null,2));await browser.close();console.log(JSON.stringify(evidence));}
})().catch(error=>{fs.writeFileSync(path.join(output,'startup-error.json'),JSON.stringify({error:String(error),stack:error.stack},null,2));console.error(error);process.exitCode=1;});
